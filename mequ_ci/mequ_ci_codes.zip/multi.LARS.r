multi.LARS = function(y,x,kMax,gap0){
	# y is the dependent variable,
	# x is a matrix of regressors,
	# kMax is the number of max cp, 

	q <- ncol(y)
	Z <- diag(q) %x% x
	Y <- as.vector(y)

	#1# Initialize things
	n <- nrow(y)		# sample size
	p <- ncol(Z)		# number of variables in regressor matrix x
	X <- Z[,1]			# first regressor variable
	X2 <- NULL
	X2[[1]] <- rep(1,nrow(Z))
	# remaining regressors
	for (i in 2:ncol(Z)) {
		X2[[i]] <- Z[,i]
		}
	nn <- nrow(Z)		# combined samples size over all responses (Tq)
	mu.hat <- rep(0,nn)	# initial mu

	## Group LARS algorithm, see yuan and lin 2006 JRSSSB

	back.seq <- nn:1
	front.seq.gap <- 1:nn			# index of (remaining) breakpoint candidates over all responses
	front.seq.gap.cps <- 1:n		# index of (remaining) breakpoint candidates

	# exclude cps at the start/end of the sample
	#front.seq.gap <- front.seq.gap[ !front.seq.gap %in% sort(-(gap0-1):gap0 + rep((0:q)*n, length(-(gap0-1):gap0))) ]
	front.seq.gap <- front.seq.gap[ !front.seq.gap %in% c(-(gap0-1):gap0 + sort(rep((0:q)*n, length(-(gap0-1):gap0)))) ]
	front.seq.gap.cps <- front.seq.gap.cps[ !front.seq.gap.cps %in% c(-(gap0-1):gap0, n + -(gap0-1):gap0) ]

	net <- c(-(gap0:1),1:gap0)		# minimum obs between cps
	old.A.index <- 0
	tol <- 1e-8
	k <- 0
	c.hat <- NULL
	X.A0 <- NULL
	x.uA <- NULL

	# start algorithm with res=y-xbeta (compute most correlated set)

	while(k < kMax){
	   #2.a# Step.a) Current correlation
		resid <- lm(Y ~ Z)$res
		# cumsum -> zeros until cp
		# c.hat = B_j v^k-1 
		c.hat[[1]] <- cumsum(X[nn:1]*resid[nn:1])[back.seq[front.seq.gap]]
		# computation for ||B_j v^k-1||
		abs.c.hat <- c.hat[[1]]^2
		# compute correlation for each regressor, add to total correlation
		for (i in 1:p){
			c.hat[[i+1]] <- cumsum(X2[[i]][nn:1]*resid[nn:1])[back.seq[front.seq.gap]]
			abs.c.hat <- abs.c.hat+c.hat[[i+1]]^2
		}

		# a column for each response
		abs.c.hat.mat <- matrix(abs.c.hat, ncol=q)
		# sum over responses for each cps candidate
		abs.c.hat.sum <- rowSums(abs.c.hat.mat)

	   #2.b# step.b) Find the active set (A.index)
		# find maximum summing over all equations (re-partitioning the matrix B v^k-1)
		Cap.C.hat <- max(abs.c.hat.sum[!(front.seq.gap.cps%in%old.A.index)])
		# select largest Cap.C.hat within tolerance
		new.A.index <- sort(unique(c(old.A.index[old.A.index > 0],front.seq.gap.cps[abs.c.hat.sum >= Cap.C.hat-tol])))
		# The indices which do not appear in the old index are the newly added variables (cp)
		add.var <- new.A.index[!(new.A.index%in%old.A.index)]  
		# index for stacked form
		add.var.stack <- add.var + rep((0:(q-1))*n, each=length(add.var)) 
		# The below 4 lines are for step 2.d
		for (i in 1:(p+1)){
			c.hat[[i]] <- c.hat[[i]][!(front.seq.gap%in%(add.var.stack+rep(net, each=q)))]
		}
		# compute a_j
		solve.a <- abs.c.hat[!(front.seq.gap%in%(add.var.stack+rep(net, each=q)))]
		front.seq.gap <- front.seq.gap[!(front.seq.gap%in%(add.var.stack+rep(net, each=q)))]
		front.seq.gap.cps <- front.seq.gap.cps[!(front.seq.gap.cps%in%(add.var+net))]
		# remove the variables close to the newly added variable.
		A.index <- new.A.index
		n.A.index <- length(A.index[A.index > 0])
		old.A.index <- new.A.index

	   #2.c# step.d) Find current direction 
		pos.A.index <- A.index[A.index > 0]

		if (k==0){
			# build first breakpoint indicator
			X.A0[[1]] <- as.matrix(outer(X[1:nn],rep(1,length(pos.A.index)))*sapply(pos.A.index,function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
			# X.A := Z_(A_k)
			X.A <- X.A0[[1]]
			for (i in 1:p) {
				# index for stacked form
				pos.A.index.stack <- pos.A.index + (ceiling(i/ncol(x))-1)*n 
				X.A0[[i+1]] <- as.matrix(outer(X2[[i]][1:nn],rep(1,length(pos.A.index.stack)))*sapply(pos.A.index.stack,function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
				X.A <- cbind(X.A,X.A0[[i+1]])
			}
			G.A <- t(X.A)%*%X.A
			Inv.X <- solve(G.A,t(X.A))	
			# descent direction:
			gamma.A.k <- Inv.X%*%resid	
			X.old <- X.A
			# needed to compute c_j
			u.A <- X.A%*%gamma.A.k
			ttt <- u.A
		} else{
			X.new <- matrix(0,nn,p+1)
			X.new[,1] <- as.matrix(outer(X[1:nn],rep(1,length(add.var)))*sapply(add.var,function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
			for (i in 1:p){
				# select from add.var.stack depending on regressor (stacked form)
				X.new[,i+1] <- as.matrix(outer(X2[[i]][1:nn],rep(1,length(add.var)))*sapply(add.var.stack[ceiling(i/ncol(x))],function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
			}	
			BB <- t(X.old)%*%X.new
			DD <- t(X.new)%*%X.new
			# H=(B'A^{-1}B-D)^{-1}t(X2)
			H <- solve(t(BB)%*%Inv.X%*%X.new-DD,t(X.new))
			HBAX1 <- H%*%X.old%*%Inv.X	
			InvXnew <- Inv.X%*%X.new
			Inv.X <- rbind(Inv.X-InvXnew%*%HBAX1+InvXnew%*%H,HBAX1-H)
			gamma.A.k <- Inv.X%*%resid
			X.old <- cbind(X.old,X.new)
			u.A <- X.old%*%gamma.A.k
		}
    
	   #2.e# step.e) Update mu.hat
		x.uA[[1]] <- cumsum(X[nn:1]*u.A[nn:1])[back.seq[front.seq.gap]]
		solve.b <- c.hat[[1]]*x.uA[[1]]
		# compute c_j for first regressor
		solve.c <- x.uA[[1]]^2
		for (i in 1:(p-1)){
			x.uA[[i+1]] <- cumsum(X2[[i]][nn:1]*u.A[nn:1])[back.seq[front.seq.gap]]
			# compute b_j
			solve.b <- solve.b + c.hat[[i+1]]*x.uA[[i+1]]
			# compute c_j
			solve.c <- solve.c + x.uA[[i+1]]^2
		}
		# solve.a is defined in step 2.b	
		# compute d_j
		solve.d <- Cap.C.hat

		solve.index1 <- (abs(solve.c-solve.d) < tol)						## if solve.c=solve.d, solve linear eq
		solve.index2 <- (abs(solve.c-solve.d) < tol) & (abs(solve.b-solve.d) < tol)	## if solve.c=solve.d, and solve.b=solve.d, no eq to solve
		solve.index3 <- (abs(solve.c-solve.d) > tol)						## otherwise, solve quadratic eq
		alphaJ <- rep(1,length(front.seq.gap))
		linear.solve <- (solve.a[solve.index1]-solve.d)/(solve.b[solve.index1]-solve.d)/2
		alphaJ[solve.index1] <- linear.solve
		alphaJ[solve.index2] <- NA

		# 2901. Solve quad eq 
		temp.s.a <- solve.a[solve.index3]
		temp.s.b <- solve.b[solve.index3]
		temp.s.c <- solve.c[solve.index3]
	
		## caution: may need to delete the below "abs".
		temp.alpha <- sqrt(abs((temp.s.b-solve.d)^2-(temp.s.a-solve.d)*(temp.s.c-solve.d)))
		# alpha^+_j
		alpha1 <- (temp.s.b-solve.d+temp.alpha)/(temp.s.c-solve.d)
		# alpha^-_j
		alpha2 <- (temp.s.b-solve.d-temp.alpha)/(temp.s.c-solve.d)
		alphaJ[solve.index3] <- alpha1*(alpha1>0)*(alpha1<=1)+alpha2*(alpha2>0)*(alpha2<=1)

		temp <- alphaJ[!(front.seq.gap%in%A.index)]
 		temp <- temp[!is.na(temp)]		## remove NA
	
		alpha.minJ <- min(temp[temp > 0])
	
		temp.ind <- (alpha.minJ==alphaJ)*(1:length(alphaJ))
		# end 2901

		if (k==0){
			pre.A.index <- pos.A.index
			order.A.index <- pos.A.index
		} else{
			order.A.index <- c(order.A.index,pos.A.index[!(pos.A.index%in%pre.A.index)])
			pre.A.index <- pos.A.index
		}

		mu.hat <- mu.hat + alpha.minJ*u.A
		k <- n.A.index
	}

	# Remove NA if there is any

	#unique is for removing redundent variables
	order.A.index <- unique(order.A.index[-(is.na(order.A.index)|(order.A.index==1))*(1:length(order.A.index))])

	order.A.index <- order.A.index
	pos.A.index <- pos.A.index

	# "1" (baseline group) must be in the pos.A.index
	if (pos.A.index[1]!=1) {pos.A.index=c(1,pos.A.index)}
	if (pos.A.index[2]-pos.A.index[1] < gap0) {pos.A.index=pos.A.index[-2]}

	X.A <- as.matrix(outer(X[1:nn],rep(1,length(pos.A.index)))*sapply(pos.A.index,function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
	X.A2 <- NULL
	for (i in 1:p){
		# select index depending on regressor (stacked form)
		pos.A.index.stack <- pos.A.index + (ceiling(i/ncol(x))-1)*n 
		X.A2[[i]] <- as.matrix(outer(X2[[i]][1:nn],rep(1,length(pos.A.index.stack)))*sapply(pos.A.index.stack,function(x){c(rep(0,x-1),rep(1,nn+1-x))}))
	}

	# Build design matrix
	ncols <- dim(X.A2[[1]])[2]
	# make matrix from list
	X.A2n <- do.call(cbind, X.A2)
	X.A2n <- X.A2n[, -c(1:ncols)]
	X.star <- cbind(X.A, X.A2n)
	old <- seq(1, dim(X.star)[2])
	# sort columns so that regressors are grouped at cps
	new <- seq(1, dim(X.star)[2], ncols)
	for (i in 2:ncols) {
		new <- c(new, seq(i, dim(X.star)[2], ncols))
	}
	X.star[, old] <- X.star[, new]
	X.star2 <- cbind(X.A2[[1]][, c(1:ncols)], X.star)

	result <- list(X.A=X.A,	X.A2=X.A2, X.star=X.star, X.star2=X.star2, cps=pos.A.index)
	return(result)
}