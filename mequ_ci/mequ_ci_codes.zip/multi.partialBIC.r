## Stepwise regression for model selection

multi.partialBIC <- function(y,X){

no.par <- ncol(as.matrix(X)) # no. parameters for each equation
nn <- nrow(y)	# sample size
q <- ncol(y)

# compute BIC for reg. without intercept (included in X)
Sig <- cov(lm(y ~ -1 + X)$resid)
ic.current <- log(abs(det(Sig))) + log(T)/T * no.par * q

ind <- 0
keep.index <- rep(1,no.par)   # The index of variables being kept
var.index <- 1:no.par
n.col.working <- 2
while((ind == 0)&(n.col.working > 1)){
	n.col.working <- ncol(as.matrix(X))
   if(n.col.working > 1){
	ic <- rep(0,n.col.working)
	for (ii in 1:n.col.working){
		Sig <- cov(lm(y ~ -1 + X[,-ii])$resid)
		# no. of parameters reduced by one
		ic[ii] <- log(abs(det(Sig))) + log(T)/T * (n.col.working-1) * q
	}	
	
	if ((ic.current < min(ic))){
		ind <- 1	
	} else {
		least.ic.index <- (1:n.col.working)*(ic==min(ic))
		X <- X[,-least.ic.index]
		var.index <- var.index[-least.ic.index]
		ic.current <- min(ic)
	}
    } else {
	Sig <- cov(lm(y ~ -1)$resid)
	# no. of parameters reduced by one
	ic0 <- log(abs(det(Sig))) + log(T)/T * (n.col.working-1) * q
	ind <- 1
	if (ic0 < ic.current){
		X <- NULL
		var.index <- NULL
	 }
    }	
}

ans <- matrix(NA, nrow=q, ncol=no.par)
if (!is.null(X)){
	fit <- lm(y~X-1)
	ans[,var.index] <- t(fit$coef)
} 

return(ans)
}







