multi.BEA <- function(y,X,X.Gp,pos.A.index,choice=c("bic","aic","qian&su","mequ"),C=1/ncol(X)) {

nn <- nrow(y)
q <- ncol(y)

n.col <- ncol(as.matrix(X))
n.Gp <- length(X.Gp)/ q

## Location of cps
A.index <- c(pos.A.index,nn+1)

## BIC
res.mat <- matrix(NA, nrow=nn, ncol=q)

for (r in 1:n.col) {		  # For each segment, do regression
	yx <- X[A.index[r]:(A.index[r+1]-1),1]

	temp.i <- 0
	if (A.index[r+1]-A.index[r] < n.Gp+1) {temp.i <- A.index[r+1]-A.index[r]-1-n.Gp}	# If No of obs (i.e. A[r+1]-A[r]) < no. parameter (i.e. n.Gp+1) 
	if (n.Gp-1+temp.i > 0){	
	   for (kk in 1:(n.Gp-1+temp.i)){
		yx <- cbind(yx,X.Gp[[kk+1]][A.index[r]:(A.index[r+1]-1),1])				#special care for the first segment
	   }
	}
	yy <- y[A.index[r]:(A.index[r+1]-1),]
	nj <- nrow(yy)

	if (nrow(yy) > 1){
		Mat <- cbind(matrix(1,ncol=1,nrow=nrow(yy)),yx)
	} else {
		Mat <- as.matrix(yx)
	}

	res.mat[A.index[r]:(A.index[r+1]-1),] <- lm(yy ~ -1 + Mat)$resid
}

Sig <- cov(res.mat)
# bic
if (choice=="bic") ic.current <- log(abs(det(Sig))) + log(T)/T * (length(A.index)-1)
# aic
if (choice=="aic") ic.current <- log(abs(det(Sig))) + 2/T * (length(A.index)-1)
# qian/su (2016)
if (choice=="qian&su") ic.current <- log(abs(det(Sig))) + 1/sqrt(T) * (length(A.index)-1)
# new criterion for multi eq.
if (choice=="mequ") ic.current <- log(abs(det(Sig))) + C * log(T)/T^0.25 * (length(A.index)-1)

ind <- 0
n.col.working <- length(A.index)-1

while( (ind == 0) & (n.col.working > 1) ){
	n.col <- length(A.index)-2          # there are length(A.index)-2 intervals after deleting any 1 change point
	ic <- rep(0,n.col)     			# The first and the last item of A.index, 1 and T+1, are not to be removed	

	A.temp <- rbind(1, combn(A.index[-c(1,length(A.index))],n.col-1), nn+1)

	for (j in 1:n.col) {
		res.mat <- matrix(NA, nrow=nn, ncol=q)

		for (r in 1:n.col) {		  # For each segment, do regression
			yx <- X[A.temp[r,j]:(A.temp[r+1,j]-1),1]

			temp.i <- 0
			if (A.temp[r+1,j]-A.temp[r,j] < n.Gp+1) {temp.i <- A.temp[r+1,j]-A.temp[r,j]-1-n.Gp}	# If No of obs (i.e. A[r+1]-A[r]) < no. parameter (i.e. n.Gp+1) 
			if (n.Gp-1+temp.i > 0){	
	  		 for (kk in 1:(n.Gp-1+temp.i)){
				yx <- cbind(yx,X.Gp[[kk+1]][A.temp[r,j]:(A.temp[r+1,j]-1),1])				#special care for the first segment
			   }
			}
			yy <- y[A.temp[r,j]:(A.temp[r+1,j]-1),]
			nj <- nrow(yy)

			if (nrow(yy) > 1){
				Mat <- cbind(matrix(1,ncol=1,nrow=nrow(yy)),yx)
			} else {
				Mat <- as.matrix(yx)
			}

			res.mat[A.temp[r,j]:(A.temp[r+1,j]-1),] <- lm(yy ~ -1 + Mat)$resid
		}

		Sig <- cov(res.mat)
		# bic
		if (choice=="bic") ic[j] <- log(abs(det(Sig))) + log(T)/T * (length(A.temp[,j])-1)
		# aic
		if (choice=="aic") ic[j] <- log(abs(det(Sig))) + 2/T * (length(A.temp[,j])-1)
		# qian/su (2016)
		if (choice=="qian&su") ic[j] <- log(abs(det(Sig))) + 1/sqrt(T) * (length(A.temp[,j])-1)
		# new criterion for multi eq.
		if (choice=="mequ") ic[j] <- log(abs(det(Sig))) + C * log(T)/T^0.25 * (length(A.temp[,j])-1)
	}

	if ( (ic.current < min(ic)) ){
		ind=1	
	} else {
		least.ic.index <- (1:length(ic))*(ic==min(ic))
		selected <- least.ic.index[least.ic.index > 0]
		A.index <- A.temp[,selected]
		ic.current <- min(ic)
		n.col.working <- n.col.working - 1
	}	
}

### Estimate the coefficients for each segment (eliminate variables from nonzero groups)

Seg.Coef <- list()
Seg.Coef.all <- list()

for (i in 1:n.col.working){
	n.i <- A.index[i+1]-A.index[i]
	XX <- X.Gp[[1]][A.index[i]:(A.index[i+1]-1),i]
	if (n.i > 1){
		XX <- cbind(XX,X[A.index[i]:(A.index[i+1]-1),i])
		temp.i <- 0
		if (n.i < n.Gp+1){temp.i <- n.i - 1 - n.Gp}
		if (n.Gp-1+temp.i >= 1){
		  for (k in 1:(n.Gp-1+temp.i)){
			XX <- cbind(XX,X.Gp[[k+1]][A.index[i]:(A.index[i+1]-1),i])
		  }	
		}
	}
	yy <- y[A.index[i]:(A.index[i+1]-1),]
	Seg.Coef[[i]] <- multi.partialBIC(yy,XX)
	Seg.Coef.all[[i]] <- t(coef(lm(yy ~ XX - 1)))
}

return(list(A=A.index, B=Seg.Coef, C=Seg.Coef.all, IC=ic.current))
}
