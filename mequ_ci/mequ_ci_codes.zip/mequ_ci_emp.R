rm(list=ls())

pac <- c("grpreg", "data.table", "matrixcalc", "glmnet")

# Install and/or load packages
checkpac <- function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x)
  }
  require(x, character.only = TRUE)
}

suppressWarnings(sapply(pac, checkpac))

source("multi.LARS.r")
source("multi.BEA_BIC.r")

#######################################
#######################################

r10y <- read.csv("THREEFY10.csv", header=T)
T <- nrow(r10y)
time <- 1:T
date <- r10y[1:T,1]
r10y <- as.numeric(as.matrix(r10y[1:T,2]))
r5y <- read.csv("THREEFY5.csv", header=T)
r5y <- as.numeric(as.matrix(r5y[1:T,2]))
r1y <- read.csv("THREEFY1.csv", header=T)
r1y <- as.numeric(as.matrix(r1y[1:T,2]))

data <- cbind(r1y,r5y,r10y)
data <- na.omit(data)
r1y <- data[,1]
r5y <- data[,2]
r10y <- data[,3]

# CI with dynamic augmentation

Y <- cbind(r10y,r5y)
x <- r1y

k <- 2

# Add leads and lags to X.star

lx <- c(NA, x[-length(x)])
dx <- x - lx
l <- length(x)
w <- dx
# constructing lead and lags
for (i in 1:k) {
	eval(parse(text=sprintf("dx_lag%s <- c(rep(NA,%s), dx[-((l+1-%s):l)])", i, i, i)))
	eval(parse(text=sprintf("dx_lead%s <- c(dx[-(1:%s)], rep(NA,%s))", i, i, i)))
	eval(parse(text=sprintf("w <- cbind(w, dx_lag%s, dx_lead%s)", i, i)))
	}

w[is.na(w)] <- 0
colnames(w) <- NULL
X <- cbind(x/sqrt(T), w)
X <- X[-c(1:(k+1),(T-k+1):T),]
Y <- Y[-c(1:(k+1),(T-k+1):T),]	

kMax <- 40
# M:12, gap:20 (5 years)
gap0 <- 50

ptm <- proc.time()
lars.obj <- multi.LARS(Y,X,kMax=kMax,gap0=gap0)
bea.obj <- multi.BEA(Y,X=lars.obj$X.A,X.Gp=lars.obj$X.A2,pos.A.index=lars.obj$cps,choice="mequ",C=1/4)
proc.time() - ptm
cps <- bea.obj$A
date[cps[-c(1,length(cps))]]

