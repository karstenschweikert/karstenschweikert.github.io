multi.BEA <- function(y,X,X.Gp,pos.A.index) {

nn <- nrow(y)
q <- ncol(y)

n.col <- ncol(as.matrix(X))
n.Gp <- length(X.Gp)/ q

## Location of cps
A.index <- c(pos.A.index,nn+1)

## MDL with all variables
temp.const <- log2(n.col) + n.col * log2(nn)
temp.sigma <- rep(0,n.col)

for (r in 1:n.col) {		  # For each segment, do regression
	yx <- X[A.index[r]:(A.index[r+1]-1),1]

	temp.i <- 0
	if (A.index[r+1]-A.index[r] < n.Gp+1) {temp.i <- A.index[r+1]-A.index[r]-1-n.Gp}	# If No of obs (i.e. A[r+1]-A[r]) < no. parameter (i.e. n.Gp+1) 
	if (n.Gp-1+temp.i > 0){	
	   for (kk in 1:(n.Gp-1+temp.i)){
		yx <- cbind(yx,X.Gp[[kk+1]][A.index[r]:(A.index[r+1]-1),1])				#special care for the first segment
	   }
	}
	yy <- y[A.index[r]:(A.index[r+1]-1),]
	nj <- nrow(yy)

	if (nrow(yy) > 1){
		Mat <- cbind(matrix(1,ncol=1,nrow=nrow(yy)),yx)
	} else {
		Mat <- as.matrix(yx)
	}

	u.temp <- lm(yy ~ -1 + Mat)$resid
	Sigj <- cov(u.temp)

	# wei, p.335 and park (1993), p.2292
	mdl.temp <- (q*n.Gp + q * (q + 1) / 2) / 2 * log2(nj) + 1/2 * (log(abs(det(Sigj))) * nj + 
			matrix.trace(u.temp %*% solve(Sigj) %*% t(u.temp)))

	# penalize very small segments
	if (nj < 15) {mdl.temp <- 100+1000*mdl.temp}
	# penalize the case where no. of obs = no. of para
	if (nj - (q*n.Gp + q * (q + 1) / 2) == 0){mdl.temp <- 1000}
	temp.sigma[r] <- mdl.temp
}
mdl.current <- temp.const+sum(temp.sigma)

ind <- 0
n.col.working <- length(A.index)-1

while( (ind == 0) & (n.col.working > 1) ){
	mdl <- rep(0,length(A.index)-2)     # The first and the last item of A.index, 1 and T+1, are not to be removed	
	n.col <- length(A.index)-2          # there are length(A.index)-2 intervals after deleting any 1 change point

	temp.const <- log2(n.col) + n.col * log2(nn)
	temp.new.sigma <- rep(0,n.col)

	for (r in 1:n.col) {		  # For each segment, do regression
		yx <- X[A.index[r]:(A.index[r+2]-1),1]

		temp.i <- 0
		if (A.index[r+2]-A.index[r] < n.Gp+1) {temp.i <- A.index[r+2]-A.index[r]-1-n.Gp}	# If No of obs (i.e. A[r+1]-A[r]) < no. parameter (i.e. n.Gp+1) 
		if (n.Gp-1+temp.i > 0){	
		   for (kk in 1:(n.Gp-1+temp.i)){
			yx <- cbind(yx,X.Gp[[kk+1]][A.index[r]:(A.index[r+2]-1),1])				#special care for the first segment
		   }
		}
		yy <- y[A.index[r]:(A.index[r+2]-1),]
		nj <- nrow(yy)

		if (nrow(yy) > 1){
			Mat <- cbind(matrix(1,ncol=1,nrow=nrow(yy)),yx)
		} else {
			Mat <- as.matrix(yx)
		}

		u.temp <- lm(yy ~ -1 + Mat)$resid
		Sigj <- cov(u.temp)
		mdl.temp <- (q*n.Gp + q * (q + 1) / 2) / 2 * log2(nj) + 1/2 * (log(abs(det(Sigj))) * nj + 
				matrix.trace(u.temp %*% solve(Sigj) %*% t(u.temp)))

		# penalize very small segments
		if (nj < 15) {mdl.temp <- 100+1000*mdl.temp}
		# penalize the case where no. of obs = no. of para
		if (nj - (q*n.Gp + q * (q + 1) / 2) == 0){mdl.temp <- 1000}
		temp.new.sigma[r] <- mdl.temp
	}

	for (jj in 1:length(mdl)){
		mdl[jj] <- temp.const + sum(temp.sigma[-c(jj,jj+1)]) + temp.new.sigma[jj]		
	}

	if ( (mdl.current < min(mdl)) ){
		ind=1	
	} else {
		least.mdl.index <- (1:length(mdl))*(mdl==min(mdl))
		selected <- least.mdl.index[least.mdl.index > 0]
		A.index <- A.index[-(1+selected)]
		mdl.current <- min(mdl)
		n.col.working <- n.col.working-1
		if (selected == 1){
			temp.sigma <- c(temp.new.sigma[selected],temp.sigma[-c(1:2)])		
		} else if (selected == length(mdl)){
			temp.sigma <- c(temp.sigma[1:(selected-1)],temp.new.sigma[selected])		
		} else {
			temp.sigma <- c(temp.sigma[1:(selected-1)],temp.new.sigma[selected],temp.sigma[(selected+2):(n.col+1)])		
		}
	}	
}

return(list(A=A.index))
}
