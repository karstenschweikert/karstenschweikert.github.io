# Enter necessary packages
pac <- c("abind", "spdep")
needed.packages <- pac

# Install and/or load packages
checkpac <- function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x)
  }
  require(x, character.only = TRUE)
}

suppressWarnings(sapply(pac, checkpac))

slfm.GMM <- function(start, y, X, W, Z, T, N) {
	# Step1 GMM
	# Initial moment weight matrix
	WN1 <- diag(dim(Z)[2]) * 0
	for (i in 1:N) {
		WN1 <- WN1 + 1/N * t(Z[,,i]) %*% Z[,,i]
		}
	WN1 <- solve(WN1)

	qd.GMM <- function(start, y, X, W, T, N, H) {
		gam <- start[1]
		lam <- start[2]	
		bet <- start[3]
		expX <- exp(X*bet) 
		g <- 0
		for (i in 1:N) {
			s <- (y[i,3:T] - (gam*y[i,2:(T-1)] + lam*(W%*%y[,3:T])[i,] ))/expX[i,3:T] - 
				(y[i,2:(T-1)] - (gam*y[i,1:(T-2)] + lam*(W%*%y[,2:(T-1)])[i,] ))/expX[i,2:(T-1)]
			g <- g + 1/N * t(s) %*% Z[,,i]
		}
		temp <- g %*% H %*% t(g)
		return(temp)
		}

	fit <- optim(par = start,fn = qd.GMM,
               method = "L-BFGS-B", lower=c(0,0,-Inf), upper=c(1,1,Inf),
               hessian = FALSE, y=y, X=X, W=W, T=T, N=N, H=WN1)
	
	gam <- fit$par[1]
	lam <- fit$par[2]
	bet <- fit$par[3]

	# Step2 GMM
	# Efficient moment weight matrix
	expX <- exp(X*bet)

	s <- (y[,3:T] - (gam*y[,2:(T-1)] + lam*W%*%y[,3:T] ))/expX[,3:T] - 
		(y[,2:(T-1)] - (gam*y[,1:(T-2)] + lam*W%*%y[,2:(T-1)] ))/expX[,2:(T-1)]

	WN2 <- diag(dim(Z)[2]) * 0
	for (i in 1:N) {
		WN2 <- WN2 + 1/N * t(Z[,,i]) %*% (t(s) %*% s) %*% Z[,,i]
		}
	WN2 <- solve(WN2)

	fit <- optim(par = start,fn = qd.GMM,
               method = "L-BFGS-B", lower=c(0,0,-Inf), upper=c(1,1,Inf),
               hessian = FALSE, y=y, X=X, W=W, T=T, N=N, H=WN2)
	result <- list(fit=fit, WN2=WN2)
	return(result)
	}

# Blundell et al. (2002), sec. 4
gamma <- 0.4
beta <- 0.5
delta <- 0.5
tau <- 0.1
sig2.eta <- 0.5
sig2.eps <- 0.5
lambda <- 0.0

N <- 400
T <- 8
R <- 1000
G <- 50 # Gibbs sampling iterations
thresh <- 25

######################################

library(foreach)
library(parallel)
library(doSNOW)
library(tcltk)
library(doRNG)

# Set up clusters for parallel computations (leave out one core)
no_cores <- detectCores() - 1
cl <- makePSOCKcluster(no_cores) 
registerDoSNOW(cl)

pb <- txtProgressBar(max=R, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

outcome <- foreach(ntests = 1:R, .combine = rbind, .packages=needed.packages,
                   .options.snow=opts, .options.RNG=1234) %dorng% {

	eta <- rnorm(N,0,sig2.eta^0.5)
	eps <- matrix(rnorm(N*T,0,sig2.eps^0.5), nrow=N, ncol=T)

	# generate spatial weight matrix (W)
	x.coord <- runif(N,0,100)
	y.coord <- runif(N,0,100)
	points <- cbind(x.coord,y.coord)
	# change cut-off value (nearest neighbors)
	dnb <- dnearneigh(points, 0, thresh)
	dsts <- nbdists(dnb, points)
	idw <- lapply(dsts, function(x) 1/x)
	tryCatch({
		W <- nb2mat(dnb, glist=idw, style="W")
		}, error = function(e) {
		print(e)                      # PRINT ERROR MESSAGE
		load(file="W.25.RData")
		})

	xi <- rnorm(N,0,sig2.eps^0.5/(1-delta^2))
	x0 <- tau/(1-delta) * eta + xi
	x <- matrix(rep(x0,T), nrow=N, ncol=T)
	y <- matrix(0, nrow=N, ncol=T)
	for (i in 1:N) {
		y[i,] <- rep(rpois(1, lambda = exp(x0[i]*beta + eta[i])),T)
		for (t in 2:T) {
			x[i,t] <- delta * x[i,t-1] + tau * eta[i] + eps[i,t]
			y[i,t] <- rpois(1, lambda = lambda*as.vector(W[i,]%*%y[,t]) + gamma*y[i,t-1] + exp(x[i,t]*beta + eta[i]))
			}
		}

	# Gibbs sampling
	for (g in 1:G) {
		for (i in 1:N) {
			for (t in 2:T) {
				y[i,t] <- rpois(1, lambda = lambda*as.vector(W[i,]%*%y[,t]) + gamma*y[i,t-1] + exp(x[i,t]*beta + eta[i]))
				}
			}
		}

#moransI <- matrix(NA, nrow=2, ncol=T)
#for (t in 1:T) {
#	temp <- moran.test(y[,t], nb2listw(dnb, glist=idw, style="W"))
#	moransI[1,t] <- temp$stat
#	moransI[2,t] <- temp$p.val
#	}

# use bootstrap to evaluate Moran's I for count data?

	# Build X and Wy matrices
	X <- x
	Wy <- W %*% y

	# Build time dummies
	date.factor <- factor(1:T)
	dummies <- model.matrix(~date.factor)

	# Instruments
	# (two lags of dependent, three lags of spatial term, two lags of X)
	nI <- 6
	Z <- array(0, c(T-2,nI,N))
	Z[1:(T-2),1,] <- t(y[,1:(T-2)])
	Z[2:(T-2),2,] <- t(y[,1:(T-3)])
	Z[1:(T-2),3,] <- t(Wy[,1:(T-2)])
	Z[2:(T-2),4,] <- t(Wy[,1:(T-3)])
	Z[1:(T-2),5,] <- t(X[,2:(T-1)]) 
	Z[1:(T-2),6,] <- t(X[,1:(T-2)])
	# using all time dummies instead of intercept

	nt <- ncol(dummies)-2
	Z.t <- array(0, c(T-2,nt,N))
	for (k in 1:nt) { 
		Z.t[1:(T-2),k,] <- dummies[3:T,k+2]
		}
	Z <- abind(Z, Z.t, along=2)

	start <- c(gamma, lambda, beta)
	estResults <- slfm.GMM(start, y, X, W, Z, T, N)

	sim.coef <- estResults$fit$par
	sim.sd <- numeric(length(start))
	alpha.est <- mean( ((1 - sim.coef[1]) * diag(N) - sim.coef[2] * W) %*% (rowSums(y) / rowSums(exp(X*sim.coef[3]))) )
	result <- list(sim.coef=sim.coef, sim.sd=sim.sd, alpha.est=alpha.est)
	return(result)
}

close(pb)

stopCluster(cl)

sim.coef <- matrix(unlist(outcome[,1]), ncol = 3, byrow = TRUE)
sim.sd <- matrix(unlist(outcome[,2]), ncol = 3, byrow = TRUE)
alpha.est <- matrix(unlist(outcome[,3]), ncol = 1, byrow = TRUE)

bias <- colMeans(sim.coef) - c(gamma, lambda, beta)
round(bias, 3)

RMSE <- function(x, y){
  	sqrt(mean((x - y)^2))
	}
round(c(RMSE(sim.coef[,1],gamma), RMSE(sim.coef[,2],lambda),
	RMSE(sim.coef[,3],beta)), 3)

rel.bias <- bias/c(gamma, lambda, beta)

colMeans(alpha.est)

save(sim.coef, file=paste("sim.coef_spatial_lambda_box_thresh", thresh, "_N", N, "_T", T, "_R", R, "_g", gamma, "_l", lambda, ".RData", sep=""))

#sim.coef/sim.sd