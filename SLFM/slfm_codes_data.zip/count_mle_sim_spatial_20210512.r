# clear workspace
rm(list=ls())

# Enter necessary packages
pac <- c("spdep")
needed.packages <- pac

# Install and/or load packages
checkpac <- function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x)
  }
  require(x, character.only = TRUE)
}

suppressWarnings(sapply(pac, checkpac))

neglog <- function(y, X, W, start) {
	K <- length(X)
	lam <- start[1]
	rh <- start[2]
	bet <- start[3:(K+2)]
	Wy <- W %*% y[,2:T]
	lWy <- W %*% y[,1:(T-1)]
	y <- y[,2:T]
	temp <- 0
	for (i in 1:N) {
		Xibeta <- 0
		for (k in 1:K) {
			Xibeta <- Xibeta + X[[k]][i,2:T] * bet[k]
			}
		Wyi <- Wy[i,]
		lWyi <- lWy[i,]
		mui <- Wyi * lam + lWyi * rh + exp(Xibeta)
		for (t in 1:(T-1)) {
			yit <- y[i,t]
			muit <- mui[t]
			temp <- temp + yit * log(muit) - yit * log(sum(mui))
			}
		}
	value <- max(c(-temp, -10^10))
	return(value)
	}

neglog <- function(y, X, W, start) {
	K <- length(X)
	lam <- start[1]
	rh <- start[2]
	bet <- start[3:(K+2)]
	Wy <- W %*% y[,2:T]
	lWy <- W %*% y[,1:(T-1)]
	y <- y[,2:T]
	temp <- numeric(N)
	for (i in 1:N) {
		yi <- y[i,]
		Xibeta <- 0
		for (k in 1:K) {
			Xibeta <- Xibeta + X[[k]][i,2:T] * bet[k]
			}
		Wyi <- Wy[i,]
		lWyi <- lWy[i,]
		temp[i] <- log(factorial(sum(yi))) - sum(log(factorial(yi))) + 
				sum(yi*log( (Wyi * lam + lWyi * rh + exp(Xibeta)) / sum(Wyi * lam + lWyi * rh + exp(Xibeta)) ))
		}
	value <- max(c(-sum(temp), -10^10))
	return(value)
	}

# Blundell et al. (2002), sec. 4

beta <- 0.5
tau <- 0.1
sig2.eta <- 0.5
sig2.eps <- 1
lambda <- 0.2
rho <- 0.5

N <- 200
T <- 8
R <- 1000
G <- 50 # Gibbs sampling iterations
thresh <- 25

######################################

library(foreach)
library(parallel)
library(doSNOW)
library(tcltk)
library(doRNG)

# Set up clusters for parallel computations (leave out one core)
no_cores <- detectCores() - 1
cl <- makePSOCKcluster(no_cores) 
registerDoSNOW(cl)

pb <- txtProgressBar(max=R, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)

outcome <- foreach(ntests = 1:R, .combine = rbind, .packages=needed.packages,
                   .options.snow=opts, .options.RNG=1234) %dorng% {

#for (ntests in 1:R) {

	eta <- rnorm(N,0,sig2.eta^0.5)
	x <- matrix(rnorm(N*T,0,sig2.eps^0.5), nrow=N, ncol=T)

	# generate spatial weight matrix (W)
	x.coord <- runif(N,0,100)
	y.coord <- runif(N,0,100)
	points <- cbind(x.coord,y.coord)
	dnb <- dnearneigh(points, 0, thresh)
	dsts <- nbdists(dnb, points)
	idw <- lapply(dsts, function(x) 1/x)
	tryCatch({
		W <- nb2mat(dnb, glist=idw, style="W")
		}, error = function(e) {
		print(e)                      # PRINT ERROR MESSAGE
		load(file="W.25.RData")
		})

	y <- matrix(0, nrow=N, ncol=T)
	for (i in 1:N) {
		y[i,] <- rep(rpois(1, lambda = exp(x[i,1]*beta + eta[i])),T)
		for (t in 2:T) {
			y[i,t] <- rpois(1, lambda = (lambda*as.vector(W[i,]%*%y[,t]) + rho*as.vector(W[i,]%*%y[,t-1])
					+ exp(x[i,t]*beta)) * exp(eta[i]))
			}
		}

	# Gibbs sampling
	for (g in 1:G) {
		for (i in 1:N) {
			for (t in 2:T) {
				y[i,t] <- rpois(1, lambda = (lambda*as.vector(W[i,]%*%y[,t]) + rho*as.vector(W[i,]%*%y[,t-1])
					+ exp(x[i,t]*beta)) * exp(eta[i]))
				}
			}
		}

#moransI <- matrix(NA, nrow=2, ncol=T)
#for (t in 1:T) {
#	#temp <- moran.test(y[,t], nb2listw(dnb, glist=idw, style="W"))
#	temp <- moran.mc(y[,t], nb2listw(dnb, glist=idw, style="W"), nsim=400, alternative="greater")
#	moransI[1,t] <- temp$stat
#	moransI[2,t] <- temp$p.val
#	}

	# Build X matrix
	X <- list(x)

	start <- c(lambda, rho, beta)
	error <- 0
	sim.coef <- rep(0,length(start))
	tryCatch({
		estResults <- optim(par=start, neglog, method="L-BFGS-B", lower=c(0,0,-Inf), upper=c(1,1,Inf),
				y=y, X=X, W=W)
		#estResults <- optim(par=start, neglog, method="Nelder-Mead", y=y, X=X, W=W)
		sim.coef <- estResults$par
		}, error = function(e) {
		print(e)                      # PRINT ERROR MESSAGE
		})
	if (all(sim.coef == 0)) error <- 1

	sim.sd <- 0	#sqrt(diag(estResults$hessian))
	result <- list(sim.coef=sim.coef, sim.sd=sim.sd, error=error)

#print(ntests)
#}


	return(result)
}

close(pb)

stopCluster(cl)

idx <- which(unlist(outcome[,3]) == 0)
length(idx)/R
sim.coef <- matrix(unlist(outcome[idx,1]), ncol = 3, byrow = TRUE)
sim.sd <- matrix(unlist(outcome[idx,2]), ncol = 1, byrow = TRUE)

bias <- colMeans(sim.coef) - c(lambda, rho, beta)
round(bias, 3)

RMSE <- function(x, y){
  	sqrt(mean((x - y)^2))
	}
round(c(RMSE(sim.coef[,1],lambda),
	RMSE(sim.coef[,2],rho), RMSE(sim.coef[,3],beta)), 3)

rel.bias <- bias/c(lambda, rho, beta)

save(sim.coef, file=paste("sim.coef_spatial_mle_thresh", thresh, "_N", N, "_T", T, "_R", R, "_l", lambda, "_r", rho, ".RData", sep=""))

#sim.coef/sim.sd