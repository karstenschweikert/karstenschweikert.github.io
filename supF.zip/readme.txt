supF.r contains the main function to compute the F* test statistics proposed in the paper.
gas_new.csv contains the data used in the empirical application.