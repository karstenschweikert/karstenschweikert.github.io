##  *************************************************************
## 
##  Function: supF.test <- supF(y, x, model=c("tar","mtar"), breaktype = c(1, 2, 3, 4), choice = c(1, 2, 3, 4), lags=NULL, thresh, u=NULL, trim = 0.15)
##  Parameters:  
##	    	y - dependent variable
##          x - independent variable(s)
##              (single vectors or data matrices)
##              
##          model - =tar  indicator function I_t
##                  =mtar indicator function M_t
##              
##          breaktype -  =1  no break       
##				 =2  C_0   
##				 =3  C/T
##                       =4  C/S
##              
##          choice -  =1  pre-specified AR lag (k = lag order)
##                    =2  AIC-chosen AR lag
##                    =3  BIC-chosen AR lag
##                    =4  General-to-specific AR lag
##              
##          lags - maximum lag
##              
##          thresh - threshold value (SETAR/MTAR)
##              
##		u - probability u (MTAR)
##              
##          trim - excluded breakpoints (percentage lateral)
##              
##  Output: F*, F.asy, AR lag, breakpoint 
##
##  *************************************************************

supF <- function(y, x, model=c("tar","mtar"), breaktype = c(1, 2, 3, 4), choice = c(1, 2, 3, 4), lags=NULL, thresh=NULL, u=NULL, trim = 0.15, ... ) 
{
	n <- length(y)
	time <- 1:n
	start <- as.integer(trim * n)
	end <- as.integer((1-trim) * n)
	f.phi <- rep(0, n)
	f.apt <- rep(0, n)
	rho1 <- rep(0, n)
	rho2 <- rep(0, n)

	for (i in start:end) {
		if (breaktype == 1) data.LR <- data.frame(cbind(y, x))
		DU <- ifelse(time >= i, 1, 0)
		if (breaktype == 2) data.LR <- data.frame(cbind(y, x, DU))
		if (breaktype == 3) data.LR <- data.frame(cbind(y, x, DU, time))
		if (breaktype == 4) {
			xDU <- DU * x
			data.LR <- data.frame(cbind(y, x, DU, xDU))
			}
		LR <- lm(y ~., data=data.LR)

		z <- LR$resid
		lz <- c(NA, z[-length(z)])
		dz <- z - lz
		ldz <- c(NA, dz[-length(dz)])
    		if(model=="tar")  { ind <- ifelse( lz  >= thresh, 1, 0) }
		if(model=="mtar") { 
			if (is.null(u) & is.null(thresh)) {
				u <- 0.5
				print('Warning: u automatically set to 0.5') }
			if (!is.null(u)) thresh <- quantile(na.omit(ldz), u)			
			ind <- ifelse( ldz >= thresh, 1, 0) }
    		pos <- lz * ind
    		neg <- lz * (1-ind)
		sim.data <- as.data.frame(cbind(dz, pos, neg))

		if (choice == 1) {
			if(lags > 0) {
				j <- 1
				while (j <= lags) {
					eval(parse(text=sprintf("ldz%s <- c(rep(NA, %s), dz[1:(length(dz)-%s)])", j, j, j)))
         				eval(parse(text=sprintf("sim.data <- cbind(sim.data,ldz%s)", j)))
         				j <- j+1
      					}
				}	
			CI <- lm(dz ~ - 1 + ., data=na.omit(sim.data))
			k <- lags + 1
    			}
		if (choice == 2) {
			CI <- list(lm(dz ~ - 1 + ., data=na.omit(sim.data)))
			k <- 1
			if(lags > 0) {
				AIC <- rep(AIC(CI[[1]]), lags+1)
				sim.data.AIC <- sim.data
				for (k in 1:lags) {
					j <- 1
					while (j <= k) {
						eval(parse(text=sprintf("ldz%s <- c(rep(NA, %s), dz[1:(length(dz)-%s)])", j, j, j)))
         					eval(parse(text=sprintf("sim.data.AIC <- cbind(sim.data.AIC,ldz%s)", j)))
         					j <- j+1
      						}		
					CI <- c(CI, list(lm(dz ~ - 1 + ., data=na.omit(sim.data.AIC))))
					AIC[k+1] <- AIC(CI[[k+1]])
					sim.data.AIC <- sim.data
					}
				k <- which.min(AIC)
				}
			CI <- CI[[k]]	
    			}
		if (choice == 3) {
			CI <- list(lm(dz ~ - 1 + ., data=na.omit(sim.data)))
			k <- 1
			if(lags > 0) {
				BIC <- rep(BIC(CI[[1]]), lags+1)
				sim.data.BIC <- sim.data
				for (k in 1:lags) {
					j <- 1
					while (j <= k) {
						eval(parse(text=sprintf("ldz%s <- c(rep(NA, %s), dz[1:(length(dz)-%s)])", j, j, j)))
         					eval(parse(text=sprintf("sim.data.BIC <- cbind(sim.data.BIC,ldz%s)", j)))
         					j <- j+1
      						}		
					CI <- c(CI, list(lm(dz ~ - 1 + ., data=na.omit(sim.data.BIC))))
					BIC[k+1] <- BIC(CI[[k+1]])
					sim.data.BIC <- sim.data
					}
				k <- which.min(BIC)
				}
			CI <- CI[[k]]	
    			}
		if (choice == 4) {
			if(lags > 0) {
				j <- 1
				while (j <= lags) {
					eval(parse(text=sprintf("ldz%s <- c(rep(NA, %s), dz[1:(length(dz)-%s)])", j, j, j)))
         				eval(parse(text=sprintf("sim.data <- cbind(sim.data,ldz%s)", j)))
         				j <- j+1
      					}
				}	
			CI <- lm(dz ~ - 1 + ., data=na.omit(sim.data))
			j <- lags + 2
			while(coef(summary(CI))[j,4] > 0.05 & j > 2) {
				sim.data <- sim.data[,-(j+1)]
				CI <- lm(dz ~ - 1 + ., data=na.omit(sim.data))
				j <- j-1
				}
			k <- j - 2 + 1
    			}
		rho1[i] <- coef(CI)[1]
		rho2[i] <- coef(CI)[2]
	  	f.phi[i] <- (coef(summary(CI))[1,3]^2 + coef(summary(CI))[2,3]^2)/2
		omega <- vcov(CI)[1,1] + vcov(CI)[2,2]
		f.apt[i] <- (rho1[i] - rho2[i])^2 / omega 
		if (breaktype == 1) break
	}
	breakp <- which.max(f.phi)
	rho1 <- rho1[breakp]
	rho2 <- rho2[breakp]

	cat ("******** sup F-Test ***********" ,"\n")
	cat ("F^* = ", max(f.phi),"\n")
	cat ("F.asy = ", f.apt[breakp],"\n")
	cat ("AR lag = ", k-1,"\n")
	cat ("Breakpoint = ", breakp,"\n")
	cat ("\n")

	result <- list(f.phi=max(f.phi), breakpoint=breakp, lags=k-1, rho1=rho1, rho2=rho2, f.apt=f.apt[breakp])
	return(result)
} 